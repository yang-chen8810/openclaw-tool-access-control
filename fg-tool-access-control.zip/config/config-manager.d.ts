import type { Config, Policy } from "../types.js";
export declare class ConfigManager {
    private configPath;
    private systemPolicyPath;
    constructor(baseDir?: string);
    getConfigPath(): string;
    loadConfig(): Promise<Config>;
    loadSystemPolicies(): Promise<Policy[]>;
    saveConfig(config: Config): Promise<void>;
}
//# sourceMappingURL=config-manager.d.ts.map