import fs from "fs/promises";
import path from "path";
import { fileURLToPath } from "url";
import { logger } from "../utils/logger.js";
const __dirname = path.dirname(fileURLToPath(import.meta.url));
export class ConfigManager {
    configPath;
    systemPolicyPath;
    constructor(baseDir) {
        const root = baseDir || path.resolve(__dirname, "..");
        this.configPath = path.join(root, "config.json");
        this.systemPolicyPath = path.join(root, "system.policy.json");
    }
    getConfigPath() {
        return this.configPath;
    }
    async loadConfig() {
        try {
            const data = await fs.readFile(this.configPath, "utf-8");
            return JSON.parse(data);
        }
        catch (error) {
            if (error.code === "ENOENT") {
                // Return default config if file doesn't exist
                return {
                    mode: "off",
                    port: 8080,
                    caseSensitive: true,
                    policies: []
                };
            }
            throw error;
        }
    }
    async loadSystemPolicies() {
        try {
            const data = await fs.readFile(this.systemPolicyPath, "utf-8");
            const parsed = JSON.parse(data);
            if (Array.isArray(parsed)) {
                return parsed;
            }
            else if (parsed && Array.isArray(parsed.policies)) {
                return parsed.policies;
            }
            logger.error(`Empty system policies`);
            return [];
        }
        catch (error) {
            // Return empty array if file doesn't exist or is invalid
            logger.error(`Failed to load system policies: ${error.message}`);
            return [];
        }
    }
    async saveConfig(config) {
        const data = JSON.stringify(config, null, 2);
        await fs.writeFile(this.configPath, data, "utf-8");
    }
}
//# sourceMappingURL=config-manager.js.map