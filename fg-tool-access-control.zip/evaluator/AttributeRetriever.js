export {};
//# sourceMappingURL=AttributeRetriever.js.map