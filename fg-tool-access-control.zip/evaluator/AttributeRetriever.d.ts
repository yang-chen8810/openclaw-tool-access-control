export interface AttributeRetriever {
    getValue(context: Record<string, any> | Map<string, any>): any;
}
//# sourceMappingURL=AttributeRetriever.d.ts.map