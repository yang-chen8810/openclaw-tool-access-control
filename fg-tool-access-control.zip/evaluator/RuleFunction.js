export {};
//# sourceMappingURL=RuleFunction.js.map