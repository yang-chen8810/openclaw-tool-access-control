import { AndExpContext, ArrayContext, AttributeContext, CompExpContext, FunctionArgContext, FunctionCallContext, JsonPathContext, LiteralContext, NotExpContext, OrExpContext, ParenExpContext, ParseContext, PrimaryContext, PrimaryExpContext } from '../antlr4/RuleExprParser.js';
import RuleExprVisitor from '../antlr4/RuleExprVisitor.js';
import type { RuleFunction } from './RuleFunction.js';
import type { AttributeRetriever } from './AttributeRetriever.js';
export declare const ERROR: unique symbol;
export declare class RuleExprEvaluator extends RuleExprVisitor<any> {
    private externalFunctions;
    private attributeRetrievers;
    private currentContext;
    private parseTree;
    private caseSensitive;
    private unconditional;
    constructor(expr: string, caseSensitive?: boolean);
    registerFunction(fn: RuleFunction): void;
    registerAttributeRetriever(name: string, retriever: AttributeRetriever): void;
    evaluate(context: Record<string, any> | null): any;
    private eval;
    visitParse: (ctx: ParseContext) => any;
    visitParenExp: (ctx: ParenExpContext) => any;
    visitNotExp: (ctx: NotExpContext) => any;
    visitAndExp: (ctx: AndExpContext) => any;
    visitOrExp: (ctx: OrExpContext) => any;
    visitCompExp: (ctx: CompExpContext) => any;
    visitPrimaryExp: (ctx: PrimaryExpContext) => any;
    visitPrimary: (ctx: PrimaryContext) => any;
    visitLiteral: (ctx: LiteralContext) => any;
    visitArray: (ctx: ArrayContext) => any;
    visitAttribute: (ctx: AttributeContext) => any;
    visitJsonPath: (ctx: JsonPathContext) => any;
    visitFunctionCall: (ctx: FunctionCallContext) => any;
    visitFunctionArg: (ctx: FunctionArgContext) => any;
    private likeMatch;
    private deepIncludes;
    private unescapeString;
    private compare;
}
//# sourceMappingURL=RuleExprEvaluator.d.ts.map