import { RuleExprEvaluator } from "./RuleExprEvaluator.js";
import type { RuleFunction } from "./RuleFunction.js";
import type { AttributeRetriever } from "./AttributeRetriever.js";
/**
 * Type guard to check if an object implements RuleFunction
 */
export declare function isRuleFunction(obj: any): obj is RuleFunction;
/**
 * Type guard to check if an object implements AttributeRetriever
 */
export declare function isAttributeRetriever(obj: any): obj is AttributeRetriever;
/**
 * Dynamically loads RuleFunctions and AttributeRetrievers from a given directory
 * and registers them with the provided RuleExprEvaluator.
 *
 * @param pluginsFolder The directory to scan for plugins
 * @param evaluator The evaluator to register the plugins with
 */
export declare function loadPlugins(pluginsFolder: string, evaluator: RuleExprEvaluator): Promise<void>;
//# sourceMappingURL=plugin-loader.d.ts.map