import { ConfigManager } from "../config/config-manager.js";
import type { Config, ToolCallEntry } from "../types.js";
import { RuleExprEvaluator } from "../evaluator/RuleExprEvaluator.js";
export interface PolicyEvaluator {
    evaluator: RuleExprEvaluator;
    desc: string;
}
export interface AccessResult {
    allowed: boolean;
    reason?: string;
}
export declare class AccessControl {
    private configManager;
    private config;
    private grantPolicyMap;
    private denyPolicyMap;
    constructor(configManager: ConfigManager);
    init(): Promise<void>;
    reload(): Promise<void>;
    private buildPolicyMap;
    getGrantPolicyMap(): Map<string, Map<string, PolicyEvaluator[]>>;
    getDenyPolicyMap(): Map<string, Map<string, PolicyEvaluator[]>>;
    getConfig(): Config | null;
    isAllowed(entry: ToolCallEntry): AccessResult;
    private evaluateAnyMatches;
}
//# sourceMappingURL=access-control.d.ts.map