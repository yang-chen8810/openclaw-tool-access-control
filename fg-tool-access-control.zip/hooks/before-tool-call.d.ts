import type { OpenClawPluginApi } from "openclaw/plugin-sdk";
export default function register(api: OpenClawPluginApi): void;
//# sourceMappingURL=before-tool-call.d.ts.map