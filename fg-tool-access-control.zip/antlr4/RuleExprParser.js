// Generated from RuleExpr.g4 by ANTLR 4.13.1
// noinspection ES6UnusedImports,JSUnusedGlobalSymbols,JSUnusedLocalSymbols
import { ATN, ATNDeserializer, DFA, FailedPredicateException, RecognitionException, NoViableAltException, BailErrorStrategy, Parser, ParserATNSimulator, RuleContext, ParserRuleContext, PredictionMode, PredictionContextCache, TerminalNode, RuleNode, Token, Interval, IntervalSet } from 'antlr4';
import RuleExprListener from "./RuleExprListener.js";
import RuleExprVisitor from "./RuleExprVisitor.js";
export default class RuleExprParser extends Parser {
    static T__0 = 1;
    static T__1 = 2;
    static T__2 = 3;
    static T__3 = 4;
    static T__4 = 5;
    static T__5 = 6;
    static T__6 = 7;
    static T__7 = 8;
    static T__8 = 9;
    static T__9 = 10;
    static T__10 = 11;
    static T__11 = 12;
    static AND = 13;
    static OR = 14;
    static NOT = 15;
    static CONTAIN = 16;
    static NOT_CONTAIN = 17;
    static MATCH = 18;
    static NOT_MATCH = 19;
    static START_WITH = 20;
    static NOT_START_WITH = 21;
    static IN = 22;
    static NOT_IN = 23;
    static LIKE = 24;
    static NOT_LIKE = 25;
    static BOOLEAN_LITERAL = 26;
    static DATETIME_LITERAL = 27;
    static DATE_LITERAL = 28;
    static DOUBLE_LITERAL = 29;
    static LONG_LITERAL = 30;
    static STRING_LITERAL = 31;
    static IDENTIFIER = 32;
    static WS = 33;
    static EOF = Token.EOF;
    static RULE_parse = 0;
    static RULE_expression = 1;
    static RULE_primary = 2;
    static RULE_functionCall = 3;
    static RULE_functionArg = 4;
    static RULE_literal = 5;
    static RULE_array = 6;
    static RULE_attribute = 7;
    static RULE_jsonPath = 8;
    static RULE_jsonStep = 9;
    static literalNames = [null, "'('",
        "')'", "'<'",
        "'<='", "'>'",
        "'>='", "'=='",
        "'!='", "','",
        "'['", "']'",
        "'.'", "'and'",
        "'or'", "'not'",
        "'contain'",
        "'not_contain'",
        "'match'", "'not_match'",
        "'start_with'",
        "'not_start_with'",
        "'in'", "'not_in'",
        "'like'", "'not_like'"];
    static symbolicNames = [null, null,
        null, null,
        null, null,
        null, null,
        null, null,
        null, null,
        null, "AND",
        "OR", "NOT",
        "CONTAIN",
        "NOT_CONTAIN",
        "MATCH", "NOT_MATCH",
        "START_WITH",
        "NOT_START_WITH",
        "IN", "NOT_IN",
        "LIKE", "NOT_LIKE",
        "BOOLEAN_LITERAL",
        "DATETIME_LITERAL",
        "DATE_LITERAL",
        "DOUBLE_LITERAL",
        "LONG_LITERAL",
        "STRING_LITERAL",
        "IDENTIFIER",
        "WS"];
    // tslint:disable:no-trailing-whitespace
    static ruleNames = [
        "parse", "expression", "primary", "functionCall", "functionArg", "literal",
        "array", "attribute", "jsonPath", "jsonStep",
    ];
    get grammarFileName() { return "RuleExpr.g4"; }
    get literalNames() { return RuleExprParser.literalNames; }
    get symbolicNames() { return RuleExprParser.symbolicNames; }
    get ruleNames() { return RuleExprParser.ruleNames; }
    get serializedATN() { return RuleExprParser._serializedATN; }
    createFailedPredicateException(predicate, message) {
        return new FailedPredicateException(this, predicate, message);
    }
    constructor(input) {
        super(input);
        this._interp = new ParserATNSimulator(this, RuleExprParser._ATN, RuleExprParser.DecisionsToDFA, new PredictionContextCache());
    }
    // @RuleVersion(0)
    parse() {
        let localctx = new ParseContext(this, this._ctx, this.state);
        this.enterRule(localctx, 0, RuleExprParser.RULE_parse);
        try {
            this.enterOuterAlt(localctx, 1);
            {
                this.state = 20;
                this.expression(0);
                this.state = 21;
                this.match(RuleExprParser.EOF);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException) {
                localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localctx;
    }
    // @RuleVersion(0)
    expression(_p) {
        if (_p === undefined) {
            _p = 0;
        }
        let _parentctx = this._ctx;
        let _parentState = this.state;
        let localctx = new ExpressionContext(this, this._ctx, _parentState);
        let _prevctx = localctx;
        let _startState = 2;
        this.enterRecursionRule(localctx, 2, RuleExprParser.RULE_expression, _p);
        let _la;
        try {
            let _alt;
            this.enterOuterAlt(localctx, 1);
            {
                this.state = 31;
                this._errHandler.sync(this);
                switch (this._input.LA(1)) {
                    case 10:
                    case 26:
                    case 27:
                    case 28:
                    case 29:
                    case 30:
                    case 31:
                    case 32:
                        {
                            localctx = new PrimaryExpContext(this, localctx);
                            this._ctx = localctx;
                            _prevctx = localctx;
                            this.state = 24;
                            this.primary();
                        }
                        break;
                    case 1:
                        {
                            localctx = new ParenExpContext(this, localctx);
                            this._ctx = localctx;
                            _prevctx = localctx;
                            this.state = 25;
                            this.match(RuleExprParser.T__0);
                            this.state = 26;
                            this.expression(0);
                            this.state = 27;
                            this.match(RuleExprParser.T__1);
                        }
                        break;
                    case 15:
                        {
                            localctx = new NotExpContext(this, localctx);
                            this._ctx = localctx;
                            _prevctx = localctx;
                            this.state = 29;
                            this.match(RuleExprParser.NOT);
                            this.state = 30;
                            this.expression(4);
                        }
                        break;
                    default:
                        throw new NoViableAltException(this);
                }
                this._ctx.stop = this._input.LT(-1);
                this.state = 44;
                this._errHandler.sync(this);
                _alt = this._interp.adaptivePredict(this._input, 2, this._ctx);
                while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
                    if (_alt === 1) {
                        if (this._parseListeners != null) {
                            this.triggerExitRuleEvent();
                        }
                        _prevctx = localctx;
                        {
                            this.state = 42;
                            this._errHandler.sync(this);
                            switch (this._interp.adaptivePredict(this._input, 1, this._ctx)) {
                                case 1:
                                    {
                                        localctx = new CompExpContext(this, new ExpressionContext(this, _parentctx, _parentState));
                                        localctx._left = _prevctx;
                                        this.pushNewRecursionContext(localctx, _startState, RuleExprParser.RULE_expression);
                                        this.state = 33;
                                        if (!(this.precpred(this._ctx, 3))) {
                                            throw this.createFailedPredicateException("this.precpred(this._ctx, 3)");
                                        }
                                        this.state = 34;
                                        localctx._op = this._input.LT(1);
                                        _la = this._input.LA(1);
                                        if (!((((_la) & ~0x1F) === 0 && ((1 << _la) & 67043832) !== 0))) {
                                            localctx._op = this._errHandler.recoverInline(this);
                                        }
                                        else {
                                            this._errHandler.reportMatch(this);
                                            this.consume();
                                        }
                                        this.state = 35;
                                        localctx._right = this.expression(4);
                                    }
                                    break;
                                case 2:
                                    {
                                        localctx = new AndExpContext(this, new ExpressionContext(this, _parentctx, _parentState));
                                        localctx._left = _prevctx;
                                        this.pushNewRecursionContext(localctx, _startState, RuleExprParser.RULE_expression);
                                        this.state = 36;
                                        if (!(this.precpred(this._ctx, 2))) {
                                            throw this.createFailedPredicateException("this.precpred(this._ctx, 2)");
                                        }
                                        this.state = 37;
                                        localctx._op = this.match(RuleExprParser.AND);
                                        this.state = 38;
                                        localctx._right = this.expression(3);
                                    }
                                    break;
                                case 3:
                                    {
                                        localctx = new OrExpContext(this, new ExpressionContext(this, _parentctx, _parentState));
                                        localctx._left = _prevctx;
                                        this.pushNewRecursionContext(localctx, _startState, RuleExprParser.RULE_expression);
                                        this.state = 39;
                                        if (!(this.precpred(this._ctx, 1))) {
                                            throw this.createFailedPredicateException("this.precpred(this._ctx, 1)");
                                        }
                                        this.state = 40;
                                        localctx._op = this.match(RuleExprParser.OR);
                                        this.state = 41;
                                        localctx._right = this.expression(2);
                                    }
                                    break;
                            }
                        }
                    }
                    this.state = 46;
                    this._errHandler.sync(this);
                    _alt = this._interp.adaptivePredict(this._input, 2, this._ctx);
                }
            }
        }
        catch (re) {
            if (re instanceof RecognitionException) {
                localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.unrollRecursionContexts(_parentctx);
        }
        return localctx;
    }
    // @RuleVersion(0)
    primary() {
        let localctx = new PrimaryContext(this, this._ctx, this.state);
        this.enterRule(localctx, 4, RuleExprParser.RULE_primary);
        try {
            this.state = 50;
            this._errHandler.sync(this);
            switch (this._interp.adaptivePredict(this._input, 3, this._ctx)) {
                case 1:
                    this.enterOuterAlt(localctx, 1);
                    {
                        this.state = 47;
                        this.literal();
                    }
                    break;
                case 2:
                    this.enterOuterAlt(localctx, 2);
                    {
                        this.state = 48;
                        this.attribute();
                    }
                    break;
                case 3:
                    this.enterOuterAlt(localctx, 3);
                    {
                        this.state = 49;
                        this.functionCall();
                    }
                    break;
            }
        }
        catch (re) {
            if (re instanceof RecognitionException) {
                localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localctx;
    }
    // @RuleVersion(0)
    functionCall() {
        let localctx = new FunctionCallContext(this, this._ctx, this.state);
        this.enterRule(localctx, 6, RuleExprParser.RULE_functionCall);
        let _la;
        try {
            this.enterOuterAlt(localctx, 1);
            {
                this.state = 52;
                this.match(RuleExprParser.IDENTIFIER);
                this.state = 53;
                this.match(RuleExprParser.T__0);
                this.state = 62;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                if (((((_la - 10)) & ~0x1F) === 0 && ((1 << (_la - 10)) & 8323073) !== 0)) {
                    {
                        this.state = 54;
                        this.functionArg();
                        this.state = 59;
                        this._errHandler.sync(this);
                        _la = this._input.LA(1);
                        while (_la === 9) {
                            {
                                {
                                    this.state = 55;
                                    this.match(RuleExprParser.T__8);
                                    this.state = 56;
                                    this.functionArg();
                                }
                            }
                            this.state = 61;
                            this._errHandler.sync(this);
                            _la = this._input.LA(1);
                        }
                    }
                }
                this.state = 64;
                this.match(RuleExprParser.T__1);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException) {
                localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localctx;
    }
    // @RuleVersion(0)
    functionArg() {
        let localctx = new FunctionArgContext(this, this._ctx, this.state);
        this.enterRule(localctx, 8, RuleExprParser.RULE_functionArg);
        try {
            this.state = 68;
            this._errHandler.sync(this);
            switch (this._input.LA(1)) {
                case 10:
                case 26:
                case 27:
                case 28:
                case 29:
                case 30:
                case 31:
                    this.enterOuterAlt(localctx, 1);
                    {
                        this.state = 66;
                        this.literal();
                    }
                    break;
                case 32:
                    this.enterOuterAlt(localctx, 2);
                    {
                        this.state = 67;
                        this.attribute();
                    }
                    break;
                default:
                    throw new NoViableAltException(this);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException) {
                localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localctx;
    }
    // @RuleVersion(0)
    literal() {
        let localctx = new LiteralContext(this, this._ctx, this.state);
        this.enterRule(localctx, 10, RuleExprParser.RULE_literal);
        try {
            this.state = 77;
            this._errHandler.sync(this);
            switch (this._input.LA(1)) {
                case 30:
                    this.enterOuterAlt(localctx, 1);
                    {
                        this.state = 70;
                        this.match(RuleExprParser.LONG_LITERAL);
                    }
                    break;
                case 29:
                    this.enterOuterAlt(localctx, 2);
                    {
                        this.state = 71;
                        this.match(RuleExprParser.DOUBLE_LITERAL);
                    }
                    break;
                case 31:
                    this.enterOuterAlt(localctx, 3);
                    {
                        this.state = 72;
                        this.match(RuleExprParser.STRING_LITERAL);
                    }
                    break;
                case 26:
                    this.enterOuterAlt(localctx, 4);
                    {
                        this.state = 73;
                        this.match(RuleExprParser.BOOLEAN_LITERAL);
                    }
                    break;
                case 28:
                    this.enterOuterAlt(localctx, 5);
                    {
                        this.state = 74;
                        this.match(RuleExprParser.DATE_LITERAL);
                    }
                    break;
                case 27:
                    this.enterOuterAlt(localctx, 6);
                    {
                        this.state = 75;
                        this.match(RuleExprParser.DATETIME_LITERAL);
                    }
                    break;
                case 10:
                    this.enterOuterAlt(localctx, 7);
                    {
                        this.state = 76;
                        this.array();
                    }
                    break;
                default:
                    throw new NoViableAltException(this);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException) {
                localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localctx;
    }
    // @RuleVersion(0)
    array() {
        let localctx = new ArrayContext(this, this._ctx, this.state);
        this.enterRule(localctx, 12, RuleExprParser.RULE_array);
        let _la;
        try {
            this.state = 92;
            this._errHandler.sync(this);
            switch (this._interp.adaptivePredict(this._input, 9, this._ctx)) {
                case 1:
                    this.enterOuterAlt(localctx, 1);
                    {
                        this.state = 79;
                        this.match(RuleExprParser.T__9);
                        this.state = 80;
                        this.literal();
                        this.state = 85;
                        this._errHandler.sync(this);
                        _la = this._input.LA(1);
                        while (_la === 9) {
                            {
                                {
                                    this.state = 81;
                                    this.match(RuleExprParser.T__8);
                                    this.state = 82;
                                    this.literal();
                                }
                            }
                            this.state = 87;
                            this._errHandler.sync(this);
                            _la = this._input.LA(1);
                        }
                        this.state = 88;
                        this.match(RuleExprParser.T__10);
                    }
                    break;
                case 2:
                    this.enterOuterAlt(localctx, 2);
                    {
                        this.state = 90;
                        this.match(RuleExprParser.T__9);
                        this.state = 91;
                        this.match(RuleExprParser.T__10);
                    }
                    break;
            }
        }
        catch (re) {
            if (re instanceof RecognitionException) {
                localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localctx;
    }
    // @RuleVersion(0)
    attribute() {
        let localctx = new AttributeContext(this, this._ctx, this.state);
        this.enterRule(localctx, 14, RuleExprParser.RULE_attribute);
        try {
            this.enterOuterAlt(localctx, 1);
            {
                this.state = 94;
                this.jsonPath();
            }
        }
        catch (re) {
            if (re instanceof RecognitionException) {
                localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localctx;
    }
    // @RuleVersion(0)
    jsonPath() {
        let localctx = new JsonPathContext(this, this._ctx, this.state);
        this.enterRule(localctx, 16, RuleExprParser.RULE_jsonPath);
        try {
            let _alt;
            this.enterOuterAlt(localctx, 1);
            {
                this.state = 96;
                this.match(RuleExprParser.IDENTIFIER);
                this.state = 100;
                this._errHandler.sync(this);
                _alt = this._interp.adaptivePredict(this._input, 10, this._ctx);
                while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
                    if (_alt === 1) {
                        {
                            {
                                this.state = 97;
                                this.jsonStep();
                            }
                        }
                    }
                    this.state = 102;
                    this._errHandler.sync(this);
                    _alt = this._interp.adaptivePredict(this._input, 10, this._ctx);
                }
            }
        }
        catch (re) {
            if (re instanceof RecognitionException) {
                localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localctx;
    }
    // @RuleVersion(0)
    jsonStep() {
        let localctx = new JsonStepContext(this, this._ctx, this.state);
        this.enterRule(localctx, 18, RuleExprParser.RULE_jsonStep);
        try {
            this.state = 111;
            this._errHandler.sync(this);
            switch (this._interp.adaptivePredict(this._input, 11, this._ctx)) {
                case 1:
                    this.enterOuterAlt(localctx, 1);
                    {
                        this.state = 103;
                        this.match(RuleExprParser.T__11);
                        this.state = 104;
                        this.match(RuleExprParser.IDENTIFIER);
                    }
                    break;
                case 2:
                    this.enterOuterAlt(localctx, 2);
                    {
                        this.state = 105;
                        this.match(RuleExprParser.T__9);
                        this.state = 106;
                        this.match(RuleExprParser.LONG_LITERAL);
                        this.state = 107;
                        this.match(RuleExprParser.T__10);
                    }
                    break;
                case 3:
                    this.enterOuterAlt(localctx, 3);
                    {
                        this.state = 108;
                        this.match(RuleExprParser.T__9);
                        this.state = 109;
                        this.match(RuleExprParser.STRING_LITERAL);
                        this.state = 110;
                        this.match(RuleExprParser.T__10);
                    }
                    break;
            }
        }
        catch (re) {
            if (re instanceof RecognitionException) {
                localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localctx;
    }
    sempred(localctx, ruleIndex, predIndex) {
        switch (ruleIndex) {
            case 1:
                return this.expression_sempred(localctx, predIndex);
        }
        return true;
    }
    expression_sempred(localctx, predIndex) {
        switch (predIndex) {
            case 0:
                return this.precpred(this._ctx, 3);
            case 1:
                return this.precpred(this._ctx, 2);
            case 2:
                return this.precpred(this._ctx, 1);
        }
        return true;
    }
    static _serializedATN = [4, 1, 33, 114, 2, 0, 7, 0, 2,
        1, 7, 1, 2, 2, 7, 2, 2, 3, 7, 3, 2, 4, 7, 4, 2, 5, 7, 5, 2, 6, 7, 6, 2, 7, 7, 7, 2, 8, 7, 8, 2, 9, 7, 9, 1,
        0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 32, 8, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 43, 8, 1, 10, 1, 12, 1, 46, 9, 1, 1, 2, 1, 2, 1, 2, 3, 2, 51, 8, 2, 1,
        3, 1, 3, 1, 3, 1, 3, 1, 3, 5, 3, 58, 8, 3, 10, 3, 12, 3, 61, 9, 3, 3, 3, 63, 8, 3, 1, 3, 1, 3, 1, 4, 1,
        4, 3, 4, 69, 8, 4, 1, 5, 1, 5, 1, 5, 1, 5, 1, 5, 1, 5, 1, 5, 3, 5, 78, 8, 5, 1, 6, 1, 6, 1, 6, 1, 6, 5, 6,
        84, 8, 6, 10, 6, 12, 6, 87, 9, 6, 1, 6, 1, 6, 1, 6, 1, 6, 3, 6, 93, 8, 6, 1, 7, 1, 7, 1, 8, 1, 8, 5, 8,
        99, 8, 8, 10, 8, 12, 8, 102, 9, 8, 1, 9, 1, 9, 1, 9, 1, 9, 1, 9, 1, 9, 1, 9, 1, 9, 3, 9, 112, 8, 9, 1,
        9, 0, 1, 2, 10, 0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 0, 1, 2, 0, 3, 8, 16, 25, 124, 0, 20, 1, 0, 0, 0,
        2, 31, 1, 0, 0, 0, 4, 50, 1, 0, 0, 0, 6, 52, 1, 0, 0, 0, 8, 68, 1, 0, 0, 0, 10, 77, 1, 0, 0, 0, 12, 92,
        1, 0, 0, 0, 14, 94, 1, 0, 0, 0, 16, 96, 1, 0, 0, 0, 18, 111, 1, 0, 0, 0, 20, 21, 3, 2, 1, 0, 21, 22,
        5, 0, 0, 1, 22, 1, 1, 0, 0, 0, 23, 24, 6, 1, -1, 0, 24, 32, 3, 4, 2, 0, 25, 26, 5, 1, 0, 0, 26, 27, 3,
        2, 1, 0, 27, 28, 5, 2, 0, 0, 28, 32, 1, 0, 0, 0, 29, 30, 5, 15, 0, 0, 30, 32, 3, 2, 1, 4, 31, 23, 1,
        0, 0, 0, 31, 25, 1, 0, 0, 0, 31, 29, 1, 0, 0, 0, 32, 44, 1, 0, 0, 0, 33, 34, 10, 3, 0, 0, 34, 35, 7,
        0, 0, 0, 35, 43, 3, 2, 1, 4, 36, 37, 10, 2, 0, 0, 37, 38, 5, 13, 0, 0, 38, 43, 3, 2, 1, 3, 39, 40, 10,
        1, 0, 0, 40, 41, 5, 14, 0, 0, 41, 43, 3, 2, 1, 2, 42, 33, 1, 0, 0, 0, 42, 36, 1, 0, 0, 0, 42, 39, 1,
        0, 0, 0, 43, 46, 1, 0, 0, 0, 44, 42, 1, 0, 0, 0, 44, 45, 1, 0, 0, 0, 45, 3, 1, 0, 0, 0, 46, 44, 1, 0,
        0, 0, 47, 51, 3, 10, 5, 0, 48, 51, 3, 14, 7, 0, 49, 51, 3, 6, 3, 0, 50, 47, 1, 0, 0, 0, 50, 48, 1, 0,
        0, 0, 50, 49, 1, 0, 0, 0, 51, 5, 1, 0, 0, 0, 52, 53, 5, 32, 0, 0, 53, 62, 5, 1, 0, 0, 54, 59, 3, 8, 4,
        0, 55, 56, 5, 9, 0, 0, 56, 58, 3, 8, 4, 0, 57, 55, 1, 0, 0, 0, 58, 61, 1, 0, 0, 0, 59, 57, 1, 0, 0, 0,
        59, 60, 1, 0, 0, 0, 60, 63, 1, 0, 0, 0, 61, 59, 1, 0, 0, 0, 62, 54, 1, 0, 0, 0, 62, 63, 1, 0, 0, 0, 63,
        64, 1, 0, 0, 0, 64, 65, 5, 2, 0, 0, 65, 7, 1, 0, 0, 0, 66, 69, 3, 10, 5, 0, 67, 69, 3, 14, 7, 0, 68,
        66, 1, 0, 0, 0, 68, 67, 1, 0, 0, 0, 69, 9, 1, 0, 0, 0, 70, 78, 5, 30, 0, 0, 71, 78, 5, 29, 0, 0, 72,
        78, 5, 31, 0, 0, 73, 78, 5, 26, 0, 0, 74, 78, 5, 28, 0, 0, 75, 78, 5, 27, 0, 0, 76, 78, 3, 12, 6, 0,
        77, 70, 1, 0, 0, 0, 77, 71, 1, 0, 0, 0, 77, 72, 1, 0, 0, 0, 77, 73, 1, 0, 0, 0, 77, 74, 1, 0, 0, 0, 77,
        75, 1, 0, 0, 0, 77, 76, 1, 0, 0, 0, 78, 11, 1, 0, 0, 0, 79, 80, 5, 10, 0, 0, 80, 85, 3, 10, 5, 0, 81,
        82, 5, 9, 0, 0, 82, 84, 3, 10, 5, 0, 83, 81, 1, 0, 0, 0, 84, 87, 1, 0, 0, 0, 85, 83, 1, 0, 0, 0, 85,
        86, 1, 0, 0, 0, 86, 88, 1, 0, 0, 0, 87, 85, 1, 0, 0, 0, 88, 89, 5, 11, 0, 0, 89, 93, 1, 0, 0, 0, 90,
        91, 5, 10, 0, 0, 91, 93, 5, 11, 0, 0, 92, 79, 1, 0, 0, 0, 92, 90, 1, 0, 0, 0, 93, 13, 1, 0, 0, 0, 94,
        95, 3, 16, 8, 0, 95, 15, 1, 0, 0, 0, 96, 100, 5, 32, 0, 0, 97, 99, 3, 18, 9, 0, 98, 97, 1, 0, 0, 0,
        99, 102, 1, 0, 0, 0, 100, 98, 1, 0, 0, 0, 100, 101, 1, 0, 0, 0, 101, 17, 1, 0, 0, 0, 102, 100, 1,
        0, 0, 0, 103, 104, 5, 12, 0, 0, 104, 112, 5, 32, 0, 0, 105, 106, 5, 10, 0, 0, 106, 107, 5, 30, 0,
        0, 107, 112, 5, 11, 0, 0, 108, 109, 5, 10, 0, 0, 109, 110, 5, 31, 0, 0, 110, 112, 5, 11, 0, 0, 111,
        103, 1, 0, 0, 0, 111, 105, 1, 0, 0, 0, 111, 108, 1, 0, 0, 0, 112, 19, 1, 0, 0, 0, 12, 31, 42, 44,
        50, 59, 62, 68, 77, 85, 92, 100, 111];
    static __ATN;
    static get _ATN() {
        if (!RuleExprParser.__ATN) {
            RuleExprParser.__ATN = new ATNDeserializer().deserialize(RuleExprParser._serializedATN);
        }
        return RuleExprParser.__ATN;
    }
    static DecisionsToDFA = RuleExprParser._ATN.decisionToState.map((ds, index) => new DFA(ds, index));
}
export class ParseContext extends ParserRuleContext {
    constructor(parser, parent, invokingState) {
        super(parent, invokingState);
        this.parser = parser;
    }
    expression() {
        return this.getTypedRuleContext(ExpressionContext, 0);
    }
    EOF() {
        return this.getToken(RuleExprParser.EOF, 0);
    }
    get ruleIndex() {
        return RuleExprParser.RULE_parse;
    }
    enterRule(listener) {
        if (listener.enterParse) {
            listener.enterParse(this);
        }
    }
    exitRule(listener) {
        if (listener.exitParse) {
            listener.exitParse(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitParse) {
            return visitor.visitParse(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class ExpressionContext extends ParserRuleContext {
    constructor(parser, parent, invokingState) {
        super(parent, invokingState);
        this.parser = parser;
    }
    get ruleIndex() {
        return RuleExprParser.RULE_expression;
    }
    copyFrom(ctx) {
        super.copyFrom(ctx);
    }
}
export class AndExpContext extends ExpressionContext {
    _left;
    _op;
    _right;
    constructor(parser, ctx) {
        super(parser, ctx.parentCtx, ctx.invokingState);
        super.copyFrom(ctx);
    }
    expression_list() {
        return this.getTypedRuleContexts(ExpressionContext);
    }
    expression(i) {
        return this.getTypedRuleContext(ExpressionContext, i);
    }
    AND() {
        return this.getToken(RuleExprParser.AND, 0);
    }
    enterRule(listener) {
        if (listener.enterAndExp) {
            listener.enterAndExp(this);
        }
    }
    exitRule(listener) {
        if (listener.exitAndExp) {
            listener.exitAndExp(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitAndExp) {
            return visitor.visitAndExp(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class CompExpContext extends ExpressionContext {
    _left;
    _op;
    _right;
    constructor(parser, ctx) {
        super(parser, ctx.parentCtx, ctx.invokingState);
        super.copyFrom(ctx);
    }
    expression_list() {
        return this.getTypedRuleContexts(ExpressionContext);
    }
    expression(i) {
        return this.getTypedRuleContext(ExpressionContext, i);
    }
    CONTAIN() {
        return this.getToken(RuleExprParser.CONTAIN, 0);
    }
    NOT_CONTAIN() {
        return this.getToken(RuleExprParser.NOT_CONTAIN, 0);
    }
    MATCH() {
        return this.getToken(RuleExprParser.MATCH, 0);
    }
    NOT_MATCH() {
        return this.getToken(RuleExprParser.NOT_MATCH, 0);
    }
    START_WITH() {
        return this.getToken(RuleExprParser.START_WITH, 0);
    }
    NOT_START_WITH() {
        return this.getToken(RuleExprParser.NOT_START_WITH, 0);
    }
    IN() {
        return this.getToken(RuleExprParser.IN, 0);
    }
    NOT_IN() {
        return this.getToken(RuleExprParser.NOT_IN, 0);
    }
    LIKE() {
        return this.getToken(RuleExprParser.LIKE, 0);
    }
    NOT_LIKE() {
        return this.getToken(RuleExprParser.NOT_LIKE, 0);
    }
    enterRule(listener) {
        if (listener.enterCompExp) {
            listener.enterCompExp(this);
        }
    }
    exitRule(listener) {
        if (listener.exitCompExp) {
            listener.exitCompExp(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitCompExp) {
            return visitor.visitCompExp(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class PrimaryExpContext extends ExpressionContext {
    constructor(parser, ctx) {
        super(parser, ctx.parentCtx, ctx.invokingState);
        super.copyFrom(ctx);
    }
    primary() {
        return this.getTypedRuleContext(PrimaryContext, 0);
    }
    enterRule(listener) {
        if (listener.enterPrimaryExp) {
            listener.enterPrimaryExp(this);
        }
    }
    exitRule(listener) {
        if (listener.exitPrimaryExp) {
            listener.exitPrimaryExp(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitPrimaryExp) {
            return visitor.visitPrimaryExp(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class ParenExpContext extends ExpressionContext {
    constructor(parser, ctx) {
        super(parser, ctx.parentCtx, ctx.invokingState);
        super.copyFrom(ctx);
    }
    expression() {
        return this.getTypedRuleContext(ExpressionContext, 0);
    }
    enterRule(listener) {
        if (listener.enterParenExp) {
            listener.enterParenExp(this);
        }
    }
    exitRule(listener) {
        if (listener.exitParenExp) {
            listener.exitParenExp(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitParenExp) {
            return visitor.visitParenExp(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class OrExpContext extends ExpressionContext {
    _left;
    _op;
    _right;
    constructor(parser, ctx) {
        super(parser, ctx.parentCtx, ctx.invokingState);
        super.copyFrom(ctx);
    }
    expression_list() {
        return this.getTypedRuleContexts(ExpressionContext);
    }
    expression(i) {
        return this.getTypedRuleContext(ExpressionContext, i);
    }
    OR() {
        return this.getToken(RuleExprParser.OR, 0);
    }
    enterRule(listener) {
        if (listener.enterOrExp) {
            listener.enterOrExp(this);
        }
    }
    exitRule(listener) {
        if (listener.exitOrExp) {
            listener.exitOrExp(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitOrExp) {
            return visitor.visitOrExp(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class NotExpContext extends ExpressionContext {
    constructor(parser, ctx) {
        super(parser, ctx.parentCtx, ctx.invokingState);
        super.copyFrom(ctx);
    }
    NOT() {
        return this.getToken(RuleExprParser.NOT, 0);
    }
    expression() {
        return this.getTypedRuleContext(ExpressionContext, 0);
    }
    enterRule(listener) {
        if (listener.enterNotExp) {
            listener.enterNotExp(this);
        }
    }
    exitRule(listener) {
        if (listener.exitNotExp) {
            listener.exitNotExp(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitNotExp) {
            return visitor.visitNotExp(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class PrimaryContext extends ParserRuleContext {
    constructor(parser, parent, invokingState) {
        super(parent, invokingState);
        this.parser = parser;
    }
    literal() {
        return this.getTypedRuleContext(LiteralContext, 0);
    }
    attribute() {
        return this.getTypedRuleContext(AttributeContext, 0);
    }
    functionCall() {
        return this.getTypedRuleContext(FunctionCallContext, 0);
    }
    get ruleIndex() {
        return RuleExprParser.RULE_primary;
    }
    enterRule(listener) {
        if (listener.enterPrimary) {
            listener.enterPrimary(this);
        }
    }
    exitRule(listener) {
        if (listener.exitPrimary) {
            listener.exitPrimary(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitPrimary) {
            return visitor.visitPrimary(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class FunctionCallContext extends ParserRuleContext {
    constructor(parser, parent, invokingState) {
        super(parent, invokingState);
        this.parser = parser;
    }
    IDENTIFIER() {
        return this.getToken(RuleExprParser.IDENTIFIER, 0);
    }
    functionArg_list() {
        return this.getTypedRuleContexts(FunctionArgContext);
    }
    functionArg(i) {
        return this.getTypedRuleContext(FunctionArgContext, i);
    }
    get ruleIndex() {
        return RuleExprParser.RULE_functionCall;
    }
    enterRule(listener) {
        if (listener.enterFunctionCall) {
            listener.enterFunctionCall(this);
        }
    }
    exitRule(listener) {
        if (listener.exitFunctionCall) {
            listener.exitFunctionCall(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitFunctionCall) {
            return visitor.visitFunctionCall(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class FunctionArgContext extends ParserRuleContext {
    constructor(parser, parent, invokingState) {
        super(parent, invokingState);
        this.parser = parser;
    }
    literal() {
        return this.getTypedRuleContext(LiteralContext, 0);
    }
    attribute() {
        return this.getTypedRuleContext(AttributeContext, 0);
    }
    get ruleIndex() {
        return RuleExprParser.RULE_functionArg;
    }
    enterRule(listener) {
        if (listener.enterFunctionArg) {
            listener.enterFunctionArg(this);
        }
    }
    exitRule(listener) {
        if (listener.exitFunctionArg) {
            listener.exitFunctionArg(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitFunctionArg) {
            return visitor.visitFunctionArg(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class LiteralContext extends ParserRuleContext {
    constructor(parser, parent, invokingState) {
        super(parent, invokingState);
        this.parser = parser;
    }
    LONG_LITERAL() {
        return this.getToken(RuleExprParser.LONG_LITERAL, 0);
    }
    DOUBLE_LITERAL() {
        return this.getToken(RuleExprParser.DOUBLE_LITERAL, 0);
    }
    STRING_LITERAL() {
        return this.getToken(RuleExprParser.STRING_LITERAL, 0);
    }
    BOOLEAN_LITERAL() {
        return this.getToken(RuleExprParser.BOOLEAN_LITERAL, 0);
    }
    DATE_LITERAL() {
        return this.getToken(RuleExprParser.DATE_LITERAL, 0);
    }
    DATETIME_LITERAL() {
        return this.getToken(RuleExprParser.DATETIME_LITERAL, 0);
    }
    array() {
        return this.getTypedRuleContext(ArrayContext, 0);
    }
    get ruleIndex() {
        return RuleExprParser.RULE_literal;
    }
    enterRule(listener) {
        if (listener.enterLiteral) {
            listener.enterLiteral(this);
        }
    }
    exitRule(listener) {
        if (listener.exitLiteral) {
            listener.exitLiteral(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitLiteral) {
            return visitor.visitLiteral(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class ArrayContext extends ParserRuleContext {
    constructor(parser, parent, invokingState) {
        super(parent, invokingState);
        this.parser = parser;
    }
    literal_list() {
        return this.getTypedRuleContexts(LiteralContext);
    }
    literal(i) {
        return this.getTypedRuleContext(LiteralContext, i);
    }
    get ruleIndex() {
        return RuleExprParser.RULE_array;
    }
    enterRule(listener) {
        if (listener.enterArray) {
            listener.enterArray(this);
        }
    }
    exitRule(listener) {
        if (listener.exitArray) {
            listener.exitArray(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitArray) {
            return visitor.visitArray(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class AttributeContext extends ParserRuleContext {
    constructor(parser, parent, invokingState) {
        super(parent, invokingState);
        this.parser = parser;
    }
    jsonPath() {
        return this.getTypedRuleContext(JsonPathContext, 0);
    }
    get ruleIndex() {
        return RuleExprParser.RULE_attribute;
    }
    enterRule(listener) {
        if (listener.enterAttribute) {
            listener.enterAttribute(this);
        }
    }
    exitRule(listener) {
        if (listener.exitAttribute) {
            listener.exitAttribute(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitAttribute) {
            return visitor.visitAttribute(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class JsonPathContext extends ParserRuleContext {
    constructor(parser, parent, invokingState) {
        super(parent, invokingState);
        this.parser = parser;
    }
    IDENTIFIER() {
        return this.getToken(RuleExprParser.IDENTIFIER, 0);
    }
    jsonStep_list() {
        return this.getTypedRuleContexts(JsonStepContext);
    }
    jsonStep(i) {
        return this.getTypedRuleContext(JsonStepContext, i);
    }
    get ruleIndex() {
        return RuleExprParser.RULE_jsonPath;
    }
    enterRule(listener) {
        if (listener.enterJsonPath) {
            listener.enterJsonPath(this);
        }
    }
    exitRule(listener) {
        if (listener.exitJsonPath) {
            listener.exitJsonPath(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitJsonPath) {
            return visitor.visitJsonPath(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
export class JsonStepContext extends ParserRuleContext {
    constructor(parser, parent, invokingState) {
        super(parent, invokingState);
        this.parser = parser;
    }
    IDENTIFIER() {
        return this.getToken(RuleExprParser.IDENTIFIER, 0);
    }
    LONG_LITERAL() {
        return this.getToken(RuleExprParser.LONG_LITERAL, 0);
    }
    STRING_LITERAL() {
        return this.getToken(RuleExprParser.STRING_LITERAL, 0);
    }
    get ruleIndex() {
        return RuleExprParser.RULE_jsonStep;
    }
    enterRule(listener) {
        if (listener.enterJsonStep) {
            listener.enterJsonStep(this);
        }
    }
    exitRule(listener) {
        if (listener.exitJsonStep) {
            listener.exitJsonStep(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitJsonStep) {
            return visitor.visitJsonStep(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
//# sourceMappingURL=RuleExprParser.js.map