// Generated from RuleExpr.g4 by ANTLR 4.13.1
import { ParseTreeListener } from "antlr4";
import { ParseContext } from "./RuleExprParser";
import { AndExpContext } from "./RuleExprParser";
import { CompExpContext } from "./RuleExprParser";
import { PrimaryExpContext } from "./RuleExprParser";
import { ParenExpContext } from "./RuleExprParser";
import { OrExpContext } from "./RuleExprParser";
import { NotExpContext } from "./RuleExprParser";
import { PrimaryContext } from "./RuleExprParser";
import { FunctionCallContext } from "./RuleExprParser";
import { FunctionArgContext } from "./RuleExprParser";
import { LiteralContext } from "./RuleExprParser";
import { ArrayContext } from "./RuleExprParser";
import { AttributeContext } from "./RuleExprParser";
import { JsonPathContext } from "./RuleExprParser";
import { JsonStepContext } from "./RuleExprParser";
/**
 * This interface defines a complete listener for a parse tree produced by
 * `RuleExprParser`.
 */
export default class RuleExprListener extends ParseTreeListener {
    /**
     * Enter a parse tree produced by `RuleExprParser.parse`.
     * @param ctx the parse tree
     */
    enterParse;
    /**
     * Exit a parse tree produced by `RuleExprParser.parse`.
     * @param ctx the parse tree
     */
    exitParse;
    /**
     * Enter a parse tree produced by the `andExp`
     * labeled alternative in `RuleExprParser.expression`.
     * @param ctx the parse tree
     */
    enterAndExp;
    /**
     * Exit a parse tree produced by the `andExp`
     * labeled alternative in `RuleExprParser.expression`.
     * @param ctx the parse tree
     */
    exitAndExp;
    /**
     * Enter a parse tree produced by the `compExp`
     * labeled alternative in `RuleExprParser.expression`.
     * @param ctx the parse tree
     */
    enterCompExp;
    /**
     * Exit a parse tree produced by the `compExp`
     * labeled alternative in `RuleExprParser.expression`.
     * @param ctx the parse tree
     */
    exitCompExp;
    /**
     * Enter a parse tree produced by the `primaryExp`
     * labeled alternative in `RuleExprParser.expression`.
     * @param ctx the parse tree
     */
    enterPrimaryExp;
    /**
     * Exit a parse tree produced by the `primaryExp`
     * labeled alternative in `RuleExprParser.expression`.
     * @param ctx the parse tree
     */
    exitPrimaryExp;
    /**
     * Enter a parse tree produced by the `parenExp`
     * labeled alternative in `RuleExprParser.expression`.
     * @param ctx the parse tree
     */
    enterParenExp;
    /**
     * Exit a parse tree produced by the `parenExp`
     * labeled alternative in `RuleExprParser.expression`.
     * @param ctx the parse tree
     */
    exitParenExp;
    /**
     * Enter a parse tree produced by the `orExp`
     * labeled alternative in `RuleExprParser.expression`.
     * @param ctx the parse tree
     */
    enterOrExp;
    /**
     * Exit a parse tree produced by the `orExp`
     * labeled alternative in `RuleExprParser.expression`.
     * @param ctx the parse tree
     */
    exitOrExp;
    /**
     * Enter a parse tree produced by the `notExp`
     * labeled alternative in `RuleExprParser.expression`.
     * @param ctx the parse tree
     */
    enterNotExp;
    /**
     * Exit a parse tree produced by the `notExp`
     * labeled alternative in `RuleExprParser.expression`.
     * @param ctx the parse tree
     */
    exitNotExp;
    /**
     * Enter a parse tree produced by `RuleExprParser.primary`.
     * @param ctx the parse tree
     */
    enterPrimary;
    /**
     * Exit a parse tree produced by `RuleExprParser.primary`.
     * @param ctx the parse tree
     */
    exitPrimary;
    /**
     * Enter a parse tree produced by `RuleExprParser.functionCall`.
     * @param ctx the parse tree
     */
    enterFunctionCall;
    /**
     * Exit a parse tree produced by `RuleExprParser.functionCall`.
     * @param ctx the parse tree
     */
    exitFunctionCall;
    /**
     * Enter a parse tree produced by `RuleExprParser.functionArg`.
     * @param ctx the parse tree
     */
    enterFunctionArg;
    /**
     * Exit a parse tree produced by `RuleExprParser.functionArg`.
     * @param ctx the parse tree
     */
    exitFunctionArg;
    /**
     * Enter a parse tree produced by `RuleExprParser.literal`.
     * @param ctx the parse tree
     */
    enterLiteral;
    /**
     * Exit a parse tree produced by `RuleExprParser.literal`.
     * @param ctx the parse tree
     */
    exitLiteral;
    /**
     * Enter a parse tree produced by `RuleExprParser.array`.
     * @param ctx the parse tree
     */
    enterArray;
    /**
     * Exit a parse tree produced by `RuleExprParser.array`.
     * @param ctx the parse tree
     */
    exitArray;
    /**
     * Enter a parse tree produced by `RuleExprParser.attribute`.
     * @param ctx the parse tree
     */
    enterAttribute;
    /**
     * Exit a parse tree produced by `RuleExprParser.attribute`.
     * @param ctx the parse tree
     */
    exitAttribute;
    /**
     * Enter a parse tree produced by `RuleExprParser.jsonPath`.
     * @param ctx the parse tree
     */
    enterJsonPath;
    /**
     * Exit a parse tree produced by `RuleExprParser.jsonPath`.
     * @param ctx the parse tree
     */
    exitJsonPath;
    /**
     * Enter a parse tree produced by `RuleExprParser.jsonStep`.
     * @param ctx the parse tree
     */
    enterJsonStep;
    /**
     * Exit a parse tree produced by `RuleExprParser.jsonStep`.
     * @param ctx the parse tree
     */
    exitJsonStep;
}
//# sourceMappingURL=RuleExprListener.js.map