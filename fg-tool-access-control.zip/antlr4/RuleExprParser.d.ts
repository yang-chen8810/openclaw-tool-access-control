import { ATN, DFA, FailedPredicateException, Parser, RuleContext, ParserRuleContext, TerminalNode, Token } from 'antlr4';
import RuleExprListener from "./RuleExprListener.js";
import RuleExprVisitor from "./RuleExprVisitor.js";
export default class RuleExprParser extends Parser {
    static readonly T__0 = 1;
    static readonly T__1 = 2;
    static readonly T__2 = 3;
    static readonly T__3 = 4;
    static readonly T__4 = 5;
    static readonly T__5 = 6;
    static readonly T__6 = 7;
    static readonly T__7 = 8;
    static readonly T__8 = 9;
    static readonly T__9 = 10;
    static readonly T__10 = 11;
    static readonly T__11 = 12;
    static readonly AND = 13;
    static readonly OR = 14;
    static readonly NOT = 15;
    static readonly CONTAIN = 16;
    static readonly NOT_CONTAIN = 17;
    static readonly MATCH = 18;
    static readonly NOT_MATCH = 19;
    static readonly START_WITH = 20;
    static readonly NOT_START_WITH = 21;
    static readonly IN = 22;
    static readonly NOT_IN = 23;
    static readonly LIKE = 24;
    static readonly NOT_LIKE = 25;
    static readonly BOOLEAN_LITERAL = 26;
    static readonly DATETIME_LITERAL = 27;
    static readonly DATE_LITERAL = 28;
    static readonly DOUBLE_LITERAL = 29;
    static readonly LONG_LITERAL = 30;
    static readonly STRING_LITERAL = 31;
    static readonly IDENTIFIER = 32;
    static readonly WS = 33;
    static readonly EOF: number;
    static readonly RULE_parse = 0;
    static readonly RULE_expression = 1;
    static readonly RULE_primary = 2;
    static readonly RULE_functionCall = 3;
    static readonly RULE_functionArg = 4;
    static readonly RULE_literal = 5;
    static readonly RULE_array = 6;
    static readonly RULE_attribute = 7;
    static readonly RULE_jsonPath = 8;
    static readonly RULE_jsonStep = 9;
    static readonly literalNames: (string | null)[];
    static readonly symbolicNames: (string | null)[];
    static readonly ruleNames: string[];
    get grammarFileName(): string;
    get literalNames(): (string | null)[];
    get symbolicNames(): (string | null)[];
    get ruleNames(): string[];
    get serializedATN(): number[];
    protected createFailedPredicateException(predicate?: string, message?: string): FailedPredicateException;
    constructor(input: any);
    parse(): ParseContext;
    expression(): ExpressionContext;
    expression(_p: number): ExpressionContext;
    primary(): PrimaryContext;
    functionCall(): FunctionCallContext;
    functionArg(): FunctionArgContext;
    literal(): LiteralContext;
    array(): ArrayContext;
    attribute(): AttributeContext;
    jsonPath(): JsonPathContext;
    jsonStep(): JsonStepContext;
    sempred(localctx: RuleContext, ruleIndex: number, predIndex: number): boolean;
    private expression_sempred;
    static readonly _serializedATN: number[];
    private static __ATN;
    static get _ATN(): ATN;
    static DecisionsToDFA: DFA[];
}
export declare class ParseContext extends ParserRuleContext {
    constructor(parser?: RuleExprParser, parent?: ParserRuleContext, invokingState?: number);
    expression(): ExpressionContext;
    EOF(): TerminalNode;
    get ruleIndex(): number;
    enterRule(listener: RuleExprListener): void;
    exitRule(listener: RuleExprListener): void;
    accept<Result>(visitor: RuleExprVisitor<Result>): Result;
}
export declare class ExpressionContext extends ParserRuleContext {
    constructor(parser?: RuleExprParser, parent?: ParserRuleContext, invokingState?: number);
    get ruleIndex(): number;
    copyFrom(ctx: ExpressionContext): void;
}
export declare class AndExpContext extends ExpressionContext {
    _left: ExpressionContext;
    _op: Token;
    _right: ExpressionContext;
    constructor(parser: RuleExprParser, ctx: ExpressionContext);
    expression_list(): ExpressionContext[];
    expression(i: number): ExpressionContext;
    AND(): TerminalNode;
    enterRule(listener: RuleExprListener): void;
    exitRule(listener: RuleExprListener): void;
    accept<Result>(visitor: RuleExprVisitor<Result>): Result;
}
export declare class CompExpContext extends ExpressionContext {
    _left: ExpressionContext;
    _op: Token;
    _right: ExpressionContext;
    constructor(parser: RuleExprParser, ctx: ExpressionContext);
    expression_list(): ExpressionContext[];
    expression(i: number): ExpressionContext;
    CONTAIN(): TerminalNode;
    NOT_CONTAIN(): TerminalNode;
    MATCH(): TerminalNode;
    NOT_MATCH(): TerminalNode;
    START_WITH(): TerminalNode;
    NOT_START_WITH(): TerminalNode;
    IN(): TerminalNode;
    NOT_IN(): TerminalNode;
    LIKE(): TerminalNode;
    NOT_LIKE(): TerminalNode;
    enterRule(listener: RuleExprListener): void;
    exitRule(listener: RuleExprListener): void;
    accept<Result>(visitor: RuleExprVisitor<Result>): Result;
}
export declare class PrimaryExpContext extends ExpressionContext {
    constructor(parser: RuleExprParser, ctx: ExpressionContext);
    primary(): PrimaryContext;
    enterRule(listener: RuleExprListener): void;
    exitRule(listener: RuleExprListener): void;
    accept<Result>(visitor: RuleExprVisitor<Result>): Result;
}
export declare class ParenExpContext extends ExpressionContext {
    constructor(parser: RuleExprParser, ctx: ExpressionContext);
    expression(): ExpressionContext;
    enterRule(listener: RuleExprListener): void;
    exitRule(listener: RuleExprListener): void;
    accept<Result>(visitor: RuleExprVisitor<Result>): Result;
}
export declare class OrExpContext extends ExpressionContext {
    _left: ExpressionContext;
    _op: Token;
    _right: ExpressionContext;
    constructor(parser: RuleExprParser, ctx: ExpressionContext);
    expression_list(): ExpressionContext[];
    expression(i: number): ExpressionContext;
    OR(): TerminalNode;
    enterRule(listener: RuleExprListener): void;
    exitRule(listener: RuleExprListener): void;
    accept<Result>(visitor: RuleExprVisitor<Result>): Result;
}
export declare class NotExpContext extends ExpressionContext {
    constructor(parser: RuleExprParser, ctx: ExpressionContext);
    NOT(): TerminalNode;
    expression(): ExpressionContext;
    enterRule(listener: RuleExprListener): void;
    exitRule(listener: RuleExprListener): void;
    accept<Result>(visitor: RuleExprVisitor<Result>): Result;
}
export declare class PrimaryContext extends ParserRuleContext {
    constructor(parser?: RuleExprParser, parent?: ParserRuleContext, invokingState?: number);
    literal(): LiteralContext;
    attribute(): AttributeContext;
    functionCall(): FunctionCallContext;
    get ruleIndex(): number;
    enterRule(listener: RuleExprListener): void;
    exitRule(listener: RuleExprListener): void;
    accept<Result>(visitor: RuleExprVisitor<Result>): Result;
}
export declare class FunctionCallContext extends ParserRuleContext {
    constructor(parser?: RuleExprParser, parent?: ParserRuleContext, invokingState?: number);
    IDENTIFIER(): TerminalNode;
    functionArg_list(): FunctionArgContext[];
    functionArg(i: number): FunctionArgContext;
    get ruleIndex(): number;
    enterRule(listener: RuleExprListener): void;
    exitRule(listener: RuleExprListener): void;
    accept<Result>(visitor: RuleExprVisitor<Result>): Result;
}
export declare class FunctionArgContext extends ParserRuleContext {
    constructor(parser?: RuleExprParser, parent?: ParserRuleContext, invokingState?: number);
    literal(): LiteralContext;
    attribute(): AttributeContext;
    get ruleIndex(): number;
    enterRule(listener: RuleExprListener): void;
    exitRule(listener: RuleExprListener): void;
    accept<Result>(visitor: RuleExprVisitor<Result>): Result;
}
export declare class LiteralContext extends ParserRuleContext {
    constructor(parser?: RuleExprParser, parent?: ParserRuleContext, invokingState?: number);
    LONG_LITERAL(): TerminalNode;
    DOUBLE_LITERAL(): TerminalNode;
    STRING_LITERAL(): TerminalNode;
    BOOLEAN_LITERAL(): TerminalNode;
    DATE_LITERAL(): TerminalNode;
    DATETIME_LITERAL(): TerminalNode;
    array(): ArrayContext;
    get ruleIndex(): number;
    enterRule(listener: RuleExprListener): void;
    exitRule(listener: RuleExprListener): void;
    accept<Result>(visitor: RuleExprVisitor<Result>): Result;
}
export declare class ArrayContext extends ParserRuleContext {
    constructor(parser?: RuleExprParser, parent?: ParserRuleContext, invokingState?: number);
    literal_list(): LiteralContext[];
    literal(i: number): LiteralContext;
    get ruleIndex(): number;
    enterRule(listener: RuleExprListener): void;
    exitRule(listener: RuleExprListener): void;
    accept<Result>(visitor: RuleExprVisitor<Result>): Result;
}
export declare class AttributeContext extends ParserRuleContext {
    constructor(parser?: RuleExprParser, parent?: ParserRuleContext, invokingState?: number);
    jsonPath(): JsonPathContext;
    get ruleIndex(): number;
    enterRule(listener: RuleExprListener): void;
    exitRule(listener: RuleExprListener): void;
    accept<Result>(visitor: RuleExprVisitor<Result>): Result;
}
export declare class JsonPathContext extends ParserRuleContext {
    constructor(parser?: RuleExprParser, parent?: ParserRuleContext, invokingState?: number);
    IDENTIFIER(): TerminalNode;
    jsonStep_list(): JsonStepContext[];
    jsonStep(i: number): JsonStepContext;
    get ruleIndex(): number;
    enterRule(listener: RuleExprListener): void;
    exitRule(listener: RuleExprListener): void;
    accept<Result>(visitor: RuleExprVisitor<Result>): Result;
}
export declare class JsonStepContext extends ParserRuleContext {
    constructor(parser?: RuleExprParser, parent?: ParserRuleContext, invokingState?: number);
    IDENTIFIER(): TerminalNode;
    LONG_LITERAL(): TerminalNode;
    STRING_LITERAL(): TerminalNode;
    get ruleIndex(): number;
    enterRule(listener: RuleExprListener): void;
    exitRule(listener: RuleExprListener): void;
    accept<Result>(visitor: RuleExprVisitor<Result>): Result;
}
//# sourceMappingURL=RuleExprParser.d.ts.map