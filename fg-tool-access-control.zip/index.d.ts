import type { OpenClawPluginApi } from "openclaw/plugin-sdk";
/**
 * Main entry point for the OpenClaw Access Control Plugin.
 * Registers the 'before_tool_call' hook to evaluate access policies.
 */
export default function register(api: OpenClawPluginApi): void;
//# sourceMappingURL=index.d.ts.map