import fs from "fs/promises";
import path from "path";
import os from "os";
import { ConfigManager } from "../config/config-manager.js";
describe("ConfigManager", () => {
    let configManager;
    let configPath;
    let testDir;
    beforeAll(async () => {
        testDir = path.join(os.tmpdir(), "openclaw-test-" + Math.random().toString(36).substring(7));
        await fs.mkdir(testDir, { recursive: true });
    });
    afterAll(async () => {
        try {
            await fs.rm(testDir, { recursive: true, force: true });
        }
        catch { }
    });
    beforeEach(() => {
        configManager = new ConfigManager(testDir);
        configPath = configManager.getConfigPath();
    });
    afterEach(async () => {
        try {
            await fs.unlink(configPath);
        }
        catch (error) {
            if (error.code !== "ENOENT") {
                throw error;
            }
        }
    });
    it("should return default config if config.json does not exist", async () => {
        const config = await configManager.loadConfig();
        expect(config).toEqual({
            mode: "off",
            port: 8080,
            caseSensitive: true,
            policies: []
        });
    });
    it("should save and load config correctly", async () => {
        const newConfig = {
            mode: "monitor",
            port: 8080,
            caseSensitive: false,
            policies: [
                { type: "grant", toolName: ["tool1"], sessionKey: ["k1"], condition: "1 == 1" }
            ]
        };
        await configManager.saveConfig(newConfig);
        const loadedConfig = await configManager.loadConfig();
        expect(loadedConfig).toEqual(newConfig);
    });
});
//# sourceMappingURL=config-manager.test.js.map