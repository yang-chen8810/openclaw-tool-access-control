/**
 * A singleton logger wrapper that allows the official OpenClaw api.logger
 * to be used across all files in the plugin.
 */
declare class PluginLogger {
    private logger;
    /**
     * Set the actual logger instance (e.g., api.logger from OpenClaw)
     */
    setLogger(logger: any): void;
    info(message: string): void;
    error(message: string): void;
    warn(message: string): void;
    debug(message: string): void;
}
export declare const logger: PluginLogger;
export {};
//# sourceMappingURL=logger.d.ts.map