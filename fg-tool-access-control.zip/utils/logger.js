/**
 * A singleton logger wrapper that allows the official OpenClaw api.logger
 * to be used across all files in the plugin.
 */
class PluginLogger {
    logger = console; // Default to console before initialization
    /**
     * Set the actual logger instance (e.g., api.logger from OpenClaw)
     */
    setLogger(logger) {
        this.logger = logger;
    }
    info(message) {
        this.logger.info ? this.logger.info(message) : console.log(message);
    }
    error(message) {
        this.logger.error ? this.logger.error(message) : console.error(message);
    }
    warn(message) {
        this.logger.warn ? this.logger.warn(message) : console.warn(message);
    }
    debug(message) {
        this.logger.debug ? this.logger.debug(message) : console.debug(message);
    }
}
export const logger = new PluginLogger();
//# sourceMappingURL=logger.js.map