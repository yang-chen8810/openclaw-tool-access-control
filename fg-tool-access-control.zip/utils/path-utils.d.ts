/**
 * Resolves a path to an absolute path.
 * If the path is relative, it is resolved against the current working directory.
 * This can be used to detect path traversal attempts ('..').
 */
export declare function resolvePath(p: string): string;
//# sourceMappingURL=path-utils.d.ts.map