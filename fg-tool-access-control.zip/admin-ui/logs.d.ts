import type { ToolCallEntry } from "../types.js";
/**
 * Loads and sanitizes log entries from the filesystem.
 * Separated into a utility to improve security audit clarity.
 */
export declare function getLatestLogs(logDir: string): Promise<ToolCallEntry[]>;
//# sourceMappingURL=logs.d.ts.map